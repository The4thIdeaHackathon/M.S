package com.example.lileej.test;


public class User {

    private String name;
    private String birth;
    private String weight;
    private String hight;
    private String blood;
    private String Pname;
    private String Pphone;
    private String add;
    private String drug;
    private String other;


    public User() {
    }

    public User(String name) {
        this.name = name;
    }

    public User(String name, String birth, String weight,String hight,String blood,String Pname,String Pphone,String add, String drug, String other) {
        this.name = name;
        this.birth = birth;
        this.weight=weight;
        this.hight=hight;
        this.blood=blood;
        this.Pname=Pname;
        this.Pphone=Pphone;
        this.add=add;
        this.drug=drug;
        this.other=other;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getbirth() {
        return birth;
    }

    public void setHouse(String birth) {
        this.birth = birth;
    }
    public String getBirth() {
        return birth;
    }
    public String getWeight() {
        return weight;
    }
    public String getHight() {
        return hight;
    }
    public String getBlood() {
        return blood;
    }
    public String getPname() {
        return Pname;
    }
    public String getPphone() {
        return Pphone;
    }
    public String getAdd() {
        return add;
    }
    public String getDrug() {
        return drug;
    }
    public String getOther() {
        return other;
    }



    @Override
    public String toString() {
        return "User{" + '\n' +
                "name='" + name + '\n' +
                "birth=\n" + birth + '\n' +
                "weight=\n" + weight + '\n' +
                "hight=\n" + hight + '\n' +
                "blood=\n" + blood + '\n' +
                "Pname=\n" + Pname + '\n' +
                "Pphone=\n" + Pphone + '\n' +
                "add=\n" + add + '\n' +
                "drug=\n" + drug + '\n' +
                "other=\n" + other + '\n' +
                '}';
    }
}
