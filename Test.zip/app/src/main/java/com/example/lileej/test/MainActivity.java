package com.example.lileej.test;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button b1 = (Button)findViewById(R.id.lock_start);
        b1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Log.d("test","서비스 실행");
                Intent intent = new Intent(getApplicationContext(),LockScreenService.class);
                startService(intent);
            }
        });
    }
}
