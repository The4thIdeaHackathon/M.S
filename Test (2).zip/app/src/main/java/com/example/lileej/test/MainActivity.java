package com.example.lileej.test;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.google.zxing.qrcode.QRCodeWriter;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button b1 = (Button)findViewById(R.id.lock_start);
        b1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                String content = ((EditText) findViewById(R.id.edt_qrcode_content)).getText().toString();//텍스트 EditText
                /// 버튼 클릭시 db에 텍스트 저장.
                Log.d("test","서비스 실행");
                Intent intent = new Intent(getApplicationContext(),LockScreenService.class);
                startService(intent);// 화면잠금 실행.

            }
        });

    }

}
