package com.example.lileej.test;

import android.content.Intent;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.view.View;
import android.widget.EditText;
import com.github.florent37.androidnosql.Listener;
import com.github.florent37.androidnosql.NoSql;
import com.example.lileej.test.User;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button b1 = (Button)findViewById(R.id.lock_start);
        final NoSql noSql=NoSql.getInstance();

        b1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                String name = ((EditText) findViewById(R.id._Name)).getText().toString();//텍스트 EditText
                String birth = ((EditText) findViewById(R.id._Birth)).getText().toString();
                String weight = ((EditText) findViewById(R.id._Weight)).getText().toString();
                String hight = ((EditText) findViewById(R.id._Hight)).getText().toString();
                String blood = ((EditText) findViewById(R.id._Blood)).getText().toString();
                String Pname = ((EditText) findViewById(R.id._Pname)).getText().toString();
                String Pphone = ((EditText) findViewById(R.id._Pphone)).getText().toString();
                /// 버튼 클릭시 db에 텍스트 저장.
                final User user = new User(
                        name,
                        birth,
                        weight,
                        hight,
                        blood,
                        Pname,
                        Pphone
                );
                noSql.notify("/user/", new Listener() {
                    @Override
                    public void nodeChanged(String path, NoSql.Value value) {

                    }
                });
                noSql.put("/user/human",user);
                Log.d("test","서비스 실행");
                Intent intent = new Intent(getApplicationContext(),LockScreenService.class);
                startService(intent);// 화면잠금 실행.

            }
        });

    }
}
