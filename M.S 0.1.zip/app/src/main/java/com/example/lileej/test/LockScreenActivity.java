package com.example.lileej.test;

import com.github.florent37.androidnosql.Listener;
import com.github.florent37.androidnosql.NoSql;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.WindowManager;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URLEncoder;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.util.Hashtable;


public class LockScreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        final NoSql noSql=NoSql.getInstance();
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                |WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        setContentView(R.layout.activity_lock_screen);

        final User userFetch = noSql.get("/user/human",User.class);
        String str = userFetch.toString();
        String user_str[]={
                userFetch.getName(),
            userFetch.getBirth(),
            userFetch.getWeight(),
            userFetch.getHight(),
            userFetch.getBlood(),
            userFetch.getPname(),
            userFetch.getPphone()
        };


        if(str==null) {
            generateRQCode("hello");
    Toast.makeText(getApplicationContext(), "실패.", Toast.LENGTH_LONG).show();
        }
        else {
            generateRQCode(str);
            Toast.makeText(getApplicationContext(), str, Toast.LENGTH_LONG).show();
        }findViewById(R.id.btn_unlock).setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                finish();
            }
        });// lock 푸는 함수
    }

    public void generateRQCode(String contents) {
        QRCodeWriter qrCodeWriter = new QRCodeWriter();
        try {
            Hashtable hints = new Hashtable();
            hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
            Bitmap bitmap = toBitmap(qrCodeWriter.encode(contents, BarcodeFormat.QR_CODE, 500, 500, hints));
            ((ImageView) findViewById(R.id.qrimage)).setImageBitmap(bitmap);
        } catch (WriterException e) {
            e.printStackTrace();
        }// imageview에 출력
    }

    public static Bitmap toBitmap(BitMatrix matrix) {
        int height = matrix.getHeight();
        int width = matrix.getWidth();
        Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                bmp.setPixel(x, y, matrix.get(x, y) ? Color.BLACK : Color.WHITE);
            }
        }
        return bmp;//qr코드 리턴
    }
}